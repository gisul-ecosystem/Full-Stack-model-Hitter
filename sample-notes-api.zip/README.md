# Notes REST API

Build a Flask Notes API with full CRUD on `/notes`.

## Run

```bash
pip install -r requirements.txt
python app.py
```

## Endpoints

- `GET /notes` — list notes
- `GET /notes/<id>` — get one note
- `POST /notes` — create note (`title`, optional `body`)
- `PUT /notes/<id>` — update note
- `DELETE /notes/<id>` — delete note
- `GET /health` — health check
