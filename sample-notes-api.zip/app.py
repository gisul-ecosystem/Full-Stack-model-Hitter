import os
from flask import Flask
from routes.notes import notes_bp

app = Flask(__name__)
app.register_blueprint(notes_bp, url_prefix="/notes")


@app.get("/health")
def health():
    return {"ok": True}


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port)
