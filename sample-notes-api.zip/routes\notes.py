from flask import Blueprint, jsonify, request

notes_bp = Blueprint("notes", __name__)

_notes = []
_next_id = 1


@notes_bp.get("")
def list_notes():
    return jsonify(_notes)


@notes_bp.get("/<int:note_id>")
def get_note(note_id):
    note = next((n for n in _notes if n["id"] == note_id), None)
    if not note:
        return jsonify({"error": "Note not found"}), 404
    return jsonify(note)


@notes_bp.post("")
def create_note():
    global _next_id
    body = request.get_json(silent=True) or {}
    note = {
        "id": _next_id,
        "title": body.get("title"),
        "body": body.get("body", ""),
    }
    _next_id += 1
    _notes.append(note)
    return jsonify(note), 201


@notes_bp.put("/<int:note_id>")
def update_note(note_id):
    note = next((n for n in _notes if n["id"] == note_id), None)
    if not note:
        return jsonify({"error": "Note not found"}), 404
    body = request.get_json(silent=True) or {}
    if "title" in body:
        note["title"] = body["title"]
    if "body" in body:
        note["body"] = body["body"]
    return jsonify(note)


@notes_bp.delete("/<int:note_id>")
def delete_note(note_id):
    global _notes
    note = next((n for n in _notes if n["id"] == note_id), None)
    _notes = [n for n in _notes if n["id"] != note_id]
    return jsonify({"deleted": note})
